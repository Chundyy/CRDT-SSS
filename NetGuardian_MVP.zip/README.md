# NetGuardian MVP

Sistema de gestão de ficheiros com encriptação e sincronização distribuída (CRDT).

## Requisitos

- Python 3.8+
- Windows/Linux/macOS

## Instalação

1. Instalar dependências:
```bash
pip install -r requirements.txt
```

2. Executar aplicação:
```bash
python main.py
```

## Funcionalidades

- Autenticação de utilizadores
- Upload/Download de ficheiros encriptados
- Dashboard moderno (CustomTkinter)
- Sincronização CRDT para ambientes distribuídos
- Base de dados PostgreSQL ou SQLite

## Configuração

Editar `config/settings.py` para configurar base de dados e outras opções.

Para ligar a PostgreSQL (Ubuntu Server):
1. Instalar PostgreSQL no servidor
2. Configurar variáveis de ambiente ou settings.py
3. A aplicação cria automaticamente as tabelas necessárias

## Estrutura

- `main.py` - Ponto de entrada
- `src/auth/` - Gestão de autenticação
- `src/database/` - Gestão de base de dados
- `src/file_manager/` - Gestão de ficheiros
- `src/gui/` - Interface gráfica
- `src/crdt/` - Sistema CRDT para sincronização
- `src/utils/` - Utilitários (encriptação, helpers)
- `config/` - Configurações
- `local_files/` - Armazenamento de ficheiros

## Licença

Uso pessoal/educacional
